import { App } from './app/app.js';

const app = new App();
