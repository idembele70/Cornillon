export class App {
  constructor() {
    console.log('class App()');
  }
}
