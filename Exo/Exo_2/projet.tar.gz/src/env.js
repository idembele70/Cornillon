export const environment = {
  urlApi: 'http://localhost:9768/data.min.json',
};
